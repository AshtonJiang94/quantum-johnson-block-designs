"""Exact integer regression for an extension of Misawa 2610.09900v1 §8.
No numerical eigensolver. Requires NumPy only for fast integer matrix sums.
Prime powers q=8 and 9 use genuine extension fields, not Z/qZ.
Run normally, without python -O.
"""
import numpy as np,itertools,json,time
from math import comb,factorial
from pathlib import Path

class Field:
 def __init__(self,q):
  self.q=q
  if q in [5,7,11]:self.p=q;self.degree=1
  elif q==8:self.p=2;self.degree=3
  elif q==9:self.p=3;self.degree=2
  else:raise ValueError(q)
 def add(self,x,y):
  if self.degree==1:return (x+y)%self.p
  if self.p==2:return x^y
  return ((x%3+y%3)%3)+3*((x//3+y//3)%3)
 def neg(self,x):
  if self.p==2:return x
  if self.degree==1:return (-x)%self.p
  return (-x%3)+3*(-(x//3)%3)
 def mul(self,x,y):
  if self.degree==1:return x*y%self.p
  if self.q==8:
   z=0
   while y:
    if y&1:z^=x
    y>>=1;x<<=1
    if x&8:x^=11 # z^3+z+1
   return z
  a,b=x%3,x//3;c,d=y%3,y//3
  return (a*c-b*d)%3+3*((a*d+b*c)%3) # z^2+1 irreducible over F3
 def inv(self,x):
  if not x:raise ZeroDivisionError
  return next(y for y in range(1,self.q) if self.mul(x,y)==1)
 def div(self,x,y):return self.mul(x,self.inv(y))
 def sub(self,x,y):return self.add(x,self.neg(y))

def vectors(F):
 q=F.q;t=q-2;V={}
 for B in itertools.combinations(range(q),2):
  a,b=B;v=np.zeros(q,dtype=np.int64)
  for x in range(q):
   if x not in B:v[x]=1
  if F.p!=2:
   m=F.div(F.add(a,b),2);assert m not in B;v[m]-=t
   norm=t*(t-1)
  else:
   c=2 # any field element outside {0,1}
   r=F.add(a,F.mul(c,F.sub(b,a)))
   s=F.add(r,F.sub(b,a));assert r!=s and r not in B and s not in B
   v[r]-=t//2;v[s]-=t//2;norm=t*(t-2)//2
  assert int(sum(v))==0 and int(v@v)==norm and norm>0
  V[B]=v
 return V,norm

def exact(q,average=True):
 F=Field(q);V,norm=vectors(F);blocks=list(V);d=q-3;t=q-2;affine=[]
 # Full field sanity: all nonzero elements have an inverse, distributivity.
 for x,y,z in itertools.product(range(q),repeat=3):assert F.mul(x,F.add(y,z))==F.add(F.mul(x,y),F.mul(x,z))
 for u in range(1,q):
  for shift in range(q):
   g=[F.add(F.mul(u,x),shift) for x in range(q)];assert len(set(g))==q;affine.append(g)
   for B,v in V.items():
    target=tuple(sorted(g[x] for x in B));w=np.zeros(q,dtype=np.int64)
    for x in range(q):w[g[x]]=v[x]
    # Even-field normalized pair is independent of the order of B.
    assert np.array_equal(np.outer(w,w),np.outer(V[target],V[target]))
 # Sharp 2-transitivity, verified independently on the orbit of (0,1).
 assert len({(g[0],g[1]) for g in affine})==q*(q-1)
 avg_result=None
 if average:
  # Verify the definition directly for C={0,1}, averaging full S_(q-2).
  sums={B:np.zeros((q,q),dtype=np.int64) for B in blocks};rest=list(range(2,q))
  for tail in itertools.permutations(rest):
   g=[0,1]+list(tail)
   for B,v in V.items():
    target=tuple(sorted(g[x] for x in B));w=np.zeros(q,dtype=np.int64)
    for x in range(q):w[g[x]]=v[x]
    sums[target]+=np.outer(w,w)
  size=factorial(q-2)
  for B,m in sums.items():
   mask=np.array([int(x not in B) for x in range(q)],dtype=np.int64)
   expected=size*norm*(t*np.diag(mask)-np.outer(mask,mask))
   assert np.array_equal(m*t*d,expected)
  avg_result={'fixed_pair':[0,1],'group_size':size,'block_matrices_verified':len(blocks),'identity_verified_by_integer_cross_multiplication':True}
 m=comb(q,2)
 involution=[F.sub(1,x) for x in range(q)]
 fixed=sum(involution[x]==x for x in range(q) if x not in [0,1])
 trace_on_standard=fixed-1
 plus=(d+trace_on_standard)//2;minus=(d-trace_on_standard)//2
 assert plus+minus==d
 if F.p==2:assert (plus,minus)==((q-4)//2,(q-2)//2)
 else:assert plus==minus==(q-3)//2
 return {'affine_optimum_parameter_dimensions':{'positive_eigenspace':plus,'negative_eigenspace':minus,'projective_dimensions':[plus-1,minus-1]},'q':q,'field':'F_'+str(q),'characteristic':F.p,'d':d,'blocks':m,'norm_squared_of_integer_vector':norm,'affine_equivariance_all_elements':len(affine),'sharp_2_transitivity_verified':True,'direct_stabilizer_average':avg_result,'minimum_effective_size':m*d,'central_effective_size':m*d*d,'ratio_central_to_optimal':d}

if __name__=='__main__':
 if not __debug__:raise RuntimeError('Do not disable assertions')
 start=time.time();rs=[]
 for q in [5,7,8,9,11]:
  r=exact(q,average=q<=9);rs.append(r);print(r,flush=True)
 result={'family':'prime powers q>=5; odd midpoint and even affine-pair orbit','proof_is_general_finite_checks_are_regressions':True,'not_usual_Haar_unitary_state_2_design':True,'priority_not_certified':True,'results':rs,'seconds':time.time()-start,'passed':True}
 Path(__file__).with_name('quantum_results.json').write_text(json.dumps(result,indent=2))
