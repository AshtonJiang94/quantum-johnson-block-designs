"""Exact finite-field regression for PGL2 higher-strength block designs.
General proofs are in manuscript.md; finite checks are not their substitute.
"""
from pathlib import Path
import sys,itertools,json,math
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parent))
from quantum_family import Field

def field(q):
 if q in [5,7,8,9,11]:return Field(q)
 if q==16:
  class F16(Field):
   def mul(self,x,y):
    z=0
    while y:
     if y&1:z^=x
     y>>=1;x<<=1
     if x&16:x^=19
    return z
  F=F16(8);F.q=16;F.degree=4;return F
 if q==4:
  class F4(Field):
   def mul(self,x,y):
    z=0
    while y:
     if y&1:z^=x
     y>>=1;x<<=1
     if x&4:x^=7
    return z
  F=F4(8);F.q=4;F.degree=2;return F
 F=Field(7);F.q=F.p=q;F.degree=1;return F

def pgl(F):
 q=F.q;G=set()
 for a,b,c,d in itertools.product(range(q),repeat=4):
  if F.sub(F.mul(a,d),F.mul(b,c))==0:continue
  g=[]
  for x in range(q+1):
   if x==q:y=q if c==0 else F.div(a,c)
   else:
    den=F.add(F.mul(c,x),d);num=F.add(F.mul(a,x),b);y=q if den==0 else F.div(num,den)
   g.append(y)
  G.add(tuple(g))
 G=sorted(G);assert len(G)==q*(q*q-1)
 assert len({(g[q],g[0],g[1]) for g in G})==len(G)
 return G

def blocks_from_base(G,B,v):
 out={}
 for g in G:
  target=tuple(sorted(g[x] for x in B))
  if target not in out:out[target]=g
 assert len(out)==math.comb(v,len(B));return out

def verify_q(q,k=3,direct=False):
 F=field(q);G=pgl(F);v=q+1;B=tuple(sorted([q,0,1])) if k==3 else (0,q);t=v-k;d=t-1
 L=[g for g in G if tuple(sorted(g[x] for x in B))==B]
 complement=[x for x in range(v) if x not in B]
 orbits=[];todo=set(complement)
 while todo:
  x=min(todo);O={g[x] for g in L};orbits.append(sorted(O));todo-=O
 if k==3:
  assert len(L)==6
  trans=[];cycles=[]
  for g in L:
   if all(g[g[x]]==x for x in B) and any(g[x]!=x for x in B):trans.append(g)
   elif any(g[x]!=x for x in B):cycles.append(g)
  assert len(trans)==3 and len(cycles)==2
  f2=sum(trans[0][x]==x for x in complement);f3=sum(cycles[0][x]==x for x in complement)
  assert all(sum(g[x]==x for x in complement)==f2 for g in trans)
  assert all(sum(g[x]==x for x in complement)==f3 for g in cycles)
  m0=(d+3*(f2-1)+2*(f3-1))//6
  ms=(d-3*(f2-1)+2*(f3-1))//6
  m2=(2*d-2*(f3-1))//6
  assert m0>=0 and ms>=0 and m2>=0 and m0+ms+2*m2==d
  if F.p==2:assert f2==0
  else:assert f2==1
  if F.p==3:expected3=1
  else:expected3=2 if q%3==1 else 0
  assert f3==expected3
  minimum_dim=1 if m0+ms else 2
  integer_vector=np.zeros(v,dtype=np.int64)
  if m0:
   O=orbits[0];assert len(O)<t
   for x in complement:integer_vector[x]=len(O)
   for x in O:integer_vector[x]-=t
  elif ms:
   def sign(g):
    permutation=[B.index(g[x]) for x in B]
    return (-1)**sum(permutation[i]>permutation[j] for i in range(3) for j in range(i+1,3))
   x=next(x for x in complement if all(sign(g)==1 for g in L if g[x]==x))
   for g in L:integer_vector[g[x]]=sign(g)
  else:
   return {'q':q,'v':v,'k':k,'d':d,'m0':m0,'ms':ms,'m2':m2,'minimum_invariant_rank':minimum_dim,'minimum_invariant_esize':math.comb(v,k)*d*minimum_dim,'full_lower_bound':math.comb(v,k)*d,'rank_one_invariant_exists':False,'full_optimum_claimed':False}
 else:
  integer_vector=np.zeros(v,dtype=np.int64)
  if q%2==0:
   return {'q':q,'v':v,'k':k,'d':d,'minimum_invariant_rank':2,'minimum_invariant_esize':math.comb(v,k)*d*2,'full_lower_bound':math.comb(v,k)*d,'rank_one_invariant_exists':False,'full_optimum_claimed':False}
  for x in complement:integer_vector[x]=1 if any(F.mul(y,y)==x for y in range(1,q)) else -1
  assert sum(integer_vector)==0
 assert int(sum(integer_vector))==0;norm=int(integer_vector@integer_vector);assert norm>0
 P=np.outer(integer_vector,integer_vector)
 for g in L:
  w=np.zeros(v,dtype=np.int64)
  for x in range(v):w[g[x]]=integer_vector[x]
  assert np.array_equal(np.outer(w,w),P)
 transports=blocks_from_base(G,B,v);V={}
 for target,g in transports.items():
  w=np.zeros(v,dtype=np.int64)
  for x in range(v):w[g[x]]=integer_vector[x]
  V[target]=w
 for g in G:
  for target,w in V.items():
   out=np.zeros(v,dtype=np.int64)
   for x in range(v):out[g[x]]=w[x]
   image=tuple(sorted(g[x] for x in target))
   assert np.array_equal(np.outer(out,out),np.outer(V[image],V[image]))
 checked=0
 if direct:
  C=B;rest=[x for x in range(v) if x not in C];summed={target:np.zeros((v,v),dtype=np.int64) for target in V}
  for perm in itertools.permutations(rest):
   g=list(range(v))
   for x,y in zip(rest,perm):g[x]=y
   for target,w in V.items():
    image=tuple(sorted(g[x] for x in target));out=np.zeros(v,dtype=np.int64)
    for x in range(v):out[g[x]]=w[x]
    summed[image]+=np.outer(out,out)
   checked+=1
  for target,M in summed.items():
   mask=np.array([int(x not in target) for x in range(v)],dtype=np.int64)
   assert np.array_equal(M*t*d,checked*norm*(t*np.diag(mask)-np.outer(mask,mask)))
 result={'q':q,'v':v,'k':k,'d':d,'blocks':len(V),'group_size':len(G),'stabilizer_size':len(L),'orbit_sizes':list(map(len,orbits)),'integer_norm':norm,'all_equivariance_checked':True,'direct_average_group_size':checked,'minimum_invariant_rank':1,'full_minimum_esize':len(V)*d,'central_esize':len(V)*d*d,'rank_one_invariant_exists':True}
 if k==3:result.update({'m0':m0,'ms':ms,'m2':m2,'fixed_points_transposition':f2,'fixed_points_3cycle':f3,'classification_projective_dimensions':[m0-1,ms-1]})
 return result

if __name__=='__main__':
 if not __debug__:raise RuntimeError('Assertions required')
 rs=[]
 for q in [4,5,7,8,9,11]:
  r=verify_q(q,3,direct=q in [7,8]);rs.append(r);print(r,flush=True)
 for q in [5,7,8]:
  r=verify_q(q,2,direct=q==5);rs.append(r);print(r,flush=True)
 Path(__file__).with_name('projective_results.json').write_text(json.dumps({'passed':True,'results':rs},indent=2))
