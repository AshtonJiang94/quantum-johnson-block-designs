"""Exact checks for multi-orbit bounds, subfield-line and partition constructions.
Finite checks are regressions; general proofs are in the paper. No Python -O.
"""
from fractions import Fraction as F
from itertools import combinations, permutations, product
from math import comb
from pathlib import Path
import json, numpy as np
from quantum_family import Field
from projective_verify import field

ROOT=Path(__file__).resolve().parent

def permutation_sign(seq):
 return (-1)**sum(seq[i]>seq[j] for i in range(len(seq)) for j in range(i+1,len(seq)))

def matrix_of(w):return np.outer(np.array(w,dtype=np.int64),np.array(w,dtype=np.int64))

def check_design(v,k,blocks,vectors,direct=False,group=None):
 norm=sum(x*x for x in next(iter(vectors.values())));assert norm>0
 mats={B:matrix_of(w) for B,w in vectors.items()}
 assert all(sum(w)==0 and sum(x*x for x in w)==norm for w in vectors.values())
 assert all(all(w[x]==0 for x in B) for B,w in vectors.items())
 if group:
  for g in group:
   for B,w in vectors.items():
    target=tuple(sorted(g[x] for x in B));out=[0]*v
    for x in range(v):out[g[x]]=w[x]
    assert target in mats and np.array_equal(matrix_of(out),mats[target])
 sums=None;checked=0
 if direct:
  t=direct;C=tuple(range(t));rest=list(range(t,v));allblocks=list(combinations(range(v),k))
  sums={B:np.zeros((v,v),dtype=np.int64) for B in allblocks}
  for perm in permutations(rest):
   g=list(range(v))
   for x,y in zip(rest,perm):g[x]=y
   for B,w in vectors.items():
    target=tuple(sorted(g[x] for x in B));out=[0]*v
    for x in range(v):out[g[x]]=w[x]
    sums[target]+=matrix_of(out)
   checked+=1
  m=comb(v,k);d=v-k-1;n=v-k;b=len(blocks)
  for B,M in sums.items():
   mask=np.array([int(x not in B) for x in range(v)],dtype=np.int64)
   projector=n*np.diag(mask)-np.outer(mask,mask)
   assert np.array_equal(M*m*d*n,checked*b*norm*projector),(v,k,B)
 return {'norm':norm,'direct_stabilizer_elements':checked,'all_equivariance_checked':bool(group)}

def line_family(q,r,direct=False):
 GF=field(q);assert (q,r) in [(4,2),(8,2),(9,3),(16,4)]
 for a,b,c in product(range(q),repeat=3):
  assert GF.mul(a,GF.add(b,c))==GF.add(GF.mul(a,b),GF.mul(a,c))
  assert GF.mul(GF.mul(a,b),c)==GF.mul(a,GF.mul(b,c))
 for a in range(1,q):assert GF.mul(a,GF.div(1,a))==1
 sub=[x for x in range(q) if GF.pow(x,r)==x] if hasattr(GF,'pow') else [x for x in range(q) if power(GF,x,r)==x]
 assert len(sub)==r
 G=[]
 for a in range(1,q):
  for b in range(q):G.append(tuple(GF.add(GF.mul(a,x),b) for x in range(q)))
 assert len({(g[0],g[1]) for g in G})==q*(q-1)
 B0=tuple(sorted(sub));L=[g for g in G if tuple(sorted(g[x] for x in B0))==B0];assert len(L)==r*(r-1)
 trans={tuple(sorted(g[x] for x in B0)):g for g in G};blocks=sorted(trans)
 R=F(q*(q-1),r*(r-1));assert len(blocks)==R
 assert all(sum(set(C)<=set(B) for B in blocks)==1 for C in combinations(range(q),2))
 comp=[x for x in range(q) if x not in B0];x=comp[0]
 assert len({g[x] for g in L})==len(L)
 # r=2: sign character of translation. r=3: multiplier character.
 # r=4: use two free L-orbits and a trivial-character difference.
 w=[0]*q
 if r in [2,3]:
  for g in L:
   perm=[B0.index(g[a]) for a in B0];w[g[x]]=permutation_sign(perm)
 else:
  gen=next(a for a in sub if a not in [0,1]); chars={1:(1,0),gen:(0,1),GF.mul(gen,gen):(-1,-1)}
  wc=[(0,0)]*q
  for g in L:
   mult=GF.sub(g[1],g[0]);wc[g[x]]=chars[mult]
  assert sum(a for a,b in wc)==0 and sum(b for a,b in wc)==0
  def cmat(w):
   a=np.array([z[0] for z in w],dtype=np.int64);b=np.array([z[1] for z in w],dtype=np.int64)
   return (np.outer(a,a)-np.outer(a,b)+np.outer(b,b),np.outer(b,a)-np.outer(a,b))
  cv={}
  for B,g in trans.items():
   out=[(0,0)]*q
   for y in range(q):out[g[y]]=wc[y]
   cv[B]=out
  cm={B:cmat(z) for B,z in cv.items()}
  for g in G:
   for B,z in cv.items():
    out=[(0,0)]*q
    for y in range(q):out[g[y]]=z[y]
    target=tuple(sorted(g[y] for y in B));M=cmat(out)
    assert all(np.array_equal(M[i],cm[target][i]) for i in [0,1])
  norm=sum(a*a-a*b+b*b for a,b in wc);assert norm==len(L)
  A,Bm=cmat(wc)
  assert np.array_equal(A@A-Bm@Bm,norm*A)
  assert np.array_equal(A@Bm+Bm@A-Bm@Bm,norm*Bm)
  assert np.array_equal(A,A.T-Bm.T) and np.array_equal(Bm,-Bm.T)
  d=q-r-1
  return {'q':q,'subfield_size':r,'strength':2,'local_dimension':d,'blocks_in_support':len(blocks),'all_blocks':comb(q,r),'minimum_esize':int(d*R),'central_minimum':int(d*d*R),'stabilizer_order':len(L),'regular_copies':int(F(q-r,r*(r-1))),'norm':norm,'direct_stabilizer_elements':0,'all_equivariance_checked':True,'coefficient_ring':'Z[omega], omega^2+omega+1=0'}
 assert sum(w)==0
 vectors={}
 for B,g in trans.items():
  out=[0]*q
  for y in range(q):out[g[y]]=w[y]
  vectors[B]=out
 res=check_design(q,r,blocks,vectors,direct=2 if direct else False,group=G)
 d=q-r-1;return {'q':q,'subfield_size':r,'strength':2,'local_dimension':d,'blocks_in_support':len(blocks),'all_blocks':comb(q,r),'minimum_esize':int(d*R),'central_minimum':int(d*d*R),'stabilizer_order':len(L),'regular_copies':int(F(q-r,r*(r-1))),**res}

def power(GF,x,n):
 y=1
 for _ in range(n):y=GF.mul(y,x)
 return y

def partition_family(v,k,direct=False):
 assert v%k==0 and v-k>=2;l=v//k;d=v-k-1
 blocks=[tuple(j+a*l for a in range(k)) for j in range(l)];B0=blocks[0];G=[tuple((x+a)%v for x in range(v)) for a in range(v)]
 w=[0]*v
 if l>=3:
  for x in blocks[1]:w[x]=1
  for x in blocks[2]:w[x]=-1
 elif k%2==0:
  for a,x in enumerate(blocks[1]):w[x]=(-1)**a
 else:
  assert k==3
  wc=[(0,0)]*v
  for a,x in enumerate(blocks[1]):wc[x]=[(1,0),(0,1),(-1,-1)][a]
  vectors={B:[wc[(x-j)%v] for x in range(v)] for j,B in enumerate(blocks)}
  def cmat(z):
   a=np.array([x[0] for x in z],dtype=np.int64);b=np.array([x[1] for x in z],dtype=np.int64)
   return (np.outer(a,a)-np.outer(a,b)+np.outer(b,b),np.outer(b,a)-np.outer(a,b))
  mats={B:cmat(z) for B,z in vectors.items()}
  for g in G:
   for B,z in vectors.items():
    out=[(0,0)]*v
    for x in range(v):out[g[x]]=z[x]
    target=tuple(sorted(g[x] for x in B));assert all(np.array_equal(cmat(out)[i],mats[target][i]) for i in [0,1])
  checked=0
  if direct:
   sums={B:[np.zeros((v,v),dtype=np.int64),np.zeros((v,v),dtype=np.int64)] for B in combinations(range(v),k)}
   for perm in permutations(range(1,v)):
    g=[0]+list(perm)
    for B,z in vectors.items():
     out=[(0,0)]*v
     for x in range(v):out[g[x]]=z[x]
     target=tuple(sorted(g[x] for x in B));M=cmat(out)
     for i in [0,1]:sums[target][i]+=M[i]
    checked+=1
   for B,(A,Bm) in sums.items():
    mask=np.array([int(x not in B) for x in range(v)],dtype=np.int64);n=v-k
    assert np.array_equal(A*comb(v,k)*d*n,checked*l*k*(n*np.diag(mask)-np.outer(mask,mask)))
    assert not np.any(Bm)
  return {'v':v,'k':k,'strength':1,'local_dimension':d,'support_blocks':l,'minimum_esize':d*l,'central_minimum':d*d*l,'norm':k,'direct_stabilizer_elements':checked,'all_equivariance_checked':True,'coefficient_ring':'Z[omega]'}
 vectors={}
 for j,B in enumerate(blocks):vectors[B]=[w[(x-j)%v] for x in range(v)]
 res=check_design(v,k,blocks,vectors,direct=1 if direct else False,group=G)
 return {'v':v,'k':k,'strength':1,'local_dimension':d,'support_blocks':l,'minimum_esize':d*l,'central_minimum':d*d*l,**res}

def spectral_tests():
 cases=0
 for dims in [(1,1,2),(2,2,3),(2,3,4),(3,3,5)]:
  r=min(dims);rn=min((x for x in dims if x>r),default=None)
  for numer in product(range(4),repeat=len(dims)):
   S=sum(numer)
   if not S:continue
   p=[F(x,S) for x in numer];purity=sum(x*x/a for x,a in zip(p,dims));assert purity<=F(1,r)
   eps=F(1,r)/purity-1
   if rn is None or eps<F(rn,r)-1:
    lam=[x/a for x,a in zip(p,dims)];j=max(range(len(lam)),key=lambda j:lam[j]);assert dims[j]==r
    dist=purity+F(1,r)-2*lam[j];assert dist<=eps/(r*(1+eps))
   cases+=1
 return {'exact_spectral_cases':cases,'purity_bound_and_stability_passed':True}

def orbit_tests():
 count=0
 for weights in [(3,5,8),(2,4),(1,7,11)]:
  for rs in [(1,2,3),(2,2,4)] if len(weights)==3 else [(1,2),(2,3)]:
   cmin=min(n*r for n,r in zip(weights,rs))
   for nums in product(range(4),repeat=len(weights)):
    if not sum(nums):continue
    p=[F(x,sum(nums)) for x in nums];purity=sum(x*x/F(n*r) for x,n,r in zip(p,weights,rs));assert purity<=F(1,cmin);count+=1
 return {'multi_orbit_scalar_cases':count,'orbit_weighted_purity_bound_passed':True}

if __name__=='__main__':
 if not __debug__:raise RuntimeError('Assertions must remain enabled')
 result={'subfield_lines':[line_family(q,r,direct=(q==9)) for q,r in [(4,2),(8,2),(9,3),(16,4)]],
 'partitions':[partition_family(v,k,direct=(v==6)) for v,k in [(6,2),(6,3),(8,4),(9,3),(12,3)]],
 'spectral':spectral_tests(),'multi_orbit':orbit_tests(),'passed':True}
 (ROOT/'new_methods_results.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
