"""Independently certify S3 character multiplicities by rational matrix ranks.
This does not enumerate whole PGL design for q=13,16.
"""
from pathlib import Path
from fractions import Fraction as F
import json,numpy as np
from projective_verify import field

def rank(M):
 a=[[F(x) for x in row] for row in M];r=0
 for c in range(len(a[0]) if a else 0):
  pivot=next((i for i in range(r,len(a)) if a[i][c]),None)
  if pivot is None:continue
  a[r],a[pivot]=a[pivot],a[r];v=a[r][c];a[r]=[x/v for x in a[r]]
  for i in range(len(a)):
   if i!=r and a[i][c]:
    v=a[i][c];a[i]=[x-v*y for x,y in zip(a[i],a[r])]
  r+=1
 return r

def qcase(q):
 K=field(q);t=q-2;d=q-3;points=list(range(q+1));B=[q,0,1];U=[x for x in points if x not in B]
 def sub(x):return K.sub(1,x) if x!=q else q
 def inv(x):return q if x==0 else 0 if x==q else K.inv(x)
 S=tuple(sub(x) for x in points);R=tuple(inv(x) for x in points);G={tuple(points)};todo=list(G)
 while todo:
  g=todo.pop()
  for h in [S,R]:
   f=tuple(h[g[x]] for x in points)
   if f not in G:G.add(f);todo.append(f)
 assert len(G)==6;G=list(G)
 matrices=[];signs=[]
 for g in G:
  mat=np.zeros((t,t),dtype=np.int64)
  for i,x in enumerate(U):mat[U.index(g[x]),i]=1
  matrices.append(mat)
  perm=[B.index(g[x]) for x in B];signs.append((-1)**sum(perm[i]>perm[j] for i in range(3) for j in range(i+1,3)))
 # The zero-sum domain is spanned by e_i-e_last. This avoids character formulas.
 E=np.eye(t,dtype=np.int64)[:,:d];E[-1,:]=-1
 P0=sum(matrices);Ps=sum(s*m for s,m in zip(signs,matrices))
 m0=rank((P0@E).tolist());ms=rank((Ps@E).tolist())
 f2=0 if K.p==2 else 1;f3=1 if K.p==3 else 2 if q%3==1 else 0
 expected0=(q-8+3*f2+2*f3)//6;expecteds=(q-2-3*f2+2*f3)//6
 assert (m0,ms)==(expected0,expecteds)
 m2=(q-2-f3)//3;assert m0+ms+2*m2==d
 for proj,char in [(P0,1),(Ps,-1)]:
  W=proj@E
  for j in range(d):
   w=W[:,j]
   if not np.any(w):continue
   assert sum(w)==0
   for s,g in zip(signs,matrices):
    assert np.array_equal(g@w,w if char==1 else s*w)
 return {'q':q,'v':q+1,'d':d,'exact_rational_projector_ranks':[m0,ms],'standard_multiplicity':m2,'projective_dimensions':[None if m0==0 else m0-1,None if ms==0 else ms-1],'all_projector_columns_equivariant':True,'full_group_average_not_computed_here':True}

if __name__=='__main__':
 if not __debug__:raise RuntimeError('Assertions required')
 rs=[qcase(q) for q in [4,5,7,8,9,11,13,16]]
 Path(__file__).with_name('classification_results.json').write_text(json.dumps({'passed':True,'results':rs},indent=2));print(json.dumps(rs,indent=2))
