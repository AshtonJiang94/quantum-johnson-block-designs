# 逐项文献比对、读取范围与贡献归属

## 结论

在本次直接读取的Misawa §7–8、Zauner1999的相关德文原文及作者英文译本、Goedicke–Vicary2023全文、Gromada相关主文版本中，未见以下具体结论被明示：本稿的局部块稳定子最小不可约维数判据、AGL的全部对称最优解参数化，以及标准补集表示下PGL₂的强度三精确最优族与S₃重数公式。

但这些工作已涵盖大量基础方法：Zauner已有群轨道生成和不可约群平均，Misawa已有量子Johnson定义、子群强度平均、迹下界及F₅最优构造。因此本稿的贡献必须描述为这些已知框架内的具体结构定理和显式延伸，不得把群轨道或Schur引理写成新的设计方法。

“相关原文未见具体结论”不是“全领域不存在先行工作”。额外关键词检索没有提供可直接核查的完全同型结果，但结果混杂，不能据此做最终优先权认证。本文是可推进的研究候选，不是完成优先权审核的投稿稿。

## 1. Misawa《Quantizing Delsarte Theory》

作者Ryutaro Misawa，arXiv:2610.09900v1，首次公开2026-10-07。直接版本：https://arxiv.org/abs/2610.09900v1 。全文：https://arxiv.org/html/2610.09900v1 。

本次完整读取并比对§7与§8（含§8.1全部锥约束论证），不是只读摘要。没有称核验整篇46页中的所有其他理论。

| 本稿对象/论证 | 原文对应 | 审核结果 |
|---|---|---|
| 诱导稳定子表示、A的分块、迹dΣTr | §7开篇和§6构造引用 | 已有框架，归属Misawa；本稿不另立原创。 |
| 逐点t稳定子平均＝常量，强度定义 | 定义7.2，式(7.1) | 完全继承，不得解释成Haar t阶矩。 |
| 强度条件＝特定等型投影消失 | 定理7.3 | 原作已解决，不能再主张新的等价性。 |
| 各块迹形成加权设计 | 命题7.4 | 已有；t=k时等块迹的推论属于基础工具。 |
| 与Zauner投影族coherence的关系 | Remark7.5，式(7.2) | 原作明确每个稳定子轨道只涉及第一张量矩，防止术语混淆。 |
| 识别任意已有coherent投影族 | Problem7.6 | 本稿没有解决，不能借对称解分类称开放问题已解。 |
| F₅中点秩一、互补最优20、中心40 | Lemma8.2、Theorem8.3 | 原作成果；本稿q=5完全重现，不是新增最优值。 |
| 同一例子的锥松弛值40/3与弱化值10 | Lemma8.5、Theorem8.6 | 原作已算精确。新族的真实最优值不是改进此LP/锥规划。 |
| AGL全部对称最优解、一般最小局部维数判据 | 原文§7容纳一般表示，§8只算具体S₅例子 | 本次未找到同一结论被明示；数学上是标准表示与原定义的具体结合，创新强度待独立评价。 |
| PGL₂三重传递强度三族及S₃重数 | §7含一般强度定义；§8没有相应族 | 本次未见直接同型结论，继续以新增研究候选推进。 |

原§8.1还使用固定群下轨道运输和稳定子交换子代数。这进一步说明“局部稳定子＋运输”是原框架已有思想；本稿新增价值应落在最优值判据、分类和具体参数族，而非声称首次使用轨道运输。

## 2. Zauner1999与2010英文译本

德文原论文：Gerhard Zauner，《Quantendesigns: Grundzüge einer nichtkommutativen Designtheorie》，Universität Wien，1999。

实际可取的作者站链接为：https://www.gerhardzauner.at/documents/gz-quantendesigns.pdf 。英文译本：https://www.gerhardzauner.at/documents/gz-quantumdesigns.pdf 。作者入口：https://www.gerhardzauner.at/qdmye.html 。此前常见的p_quantendesigns.html和导师站旧链接本次返回404；这次通过实际页面找到了两份全文，并非靠搜索摘要推断。

本次阅读：德文定义1.1、§2.5及§3.2相关论证；英文对应定义、群与轨道部分、§3.2–3.3，并对照其范围。不是逐式复核整部76页德文论文的全部章节。

| 原作内容 | 实际定位 | 与本稿关系 |
|---|---|---|
| 正交投影集合，regular、coherent、t-coherent定义 | 德文定义1.1，PDF第6页；英文定义1.1，PDF第8页 | 已有基础。coherent是ΣP=kI；tensor t-coherence不是本稿Johnson强度。 |
| 不可约群下1-coherence等价coherence | Proposition1.3 | Schur平均是成熟工具，不能主张新的基本原理。 |
| 自同构轨道保持所有张量矩，若群不可约则coherent | Proposition2.32；德文PDF第48页，英文第51页 | 群轨道与平均已有。并不自动给底层S_v逐点稳定子的Misawa强度条件。 |
| 传递群＋初始投影生成整个设计 | §2.5后半；德文PDF第50页附近，英文第53页附近 | 完全覆盖“从seed生成orbit”方法；本稿不列其为原创。 |
| 素数幂最大affine quantum2-design | Satz/Theorem3.1；德文PDF第55页、英文第58页 | 这是Weyl/MUB与可分解正交类意义下的affine design，不是AGL点传递、补集标准表示的本稿量子Johnson族。不能因同有affine和prime power即认定相同，也不能说Zauner没有无穷族。 |
| tensor-product等扩展 | §3.3 | 成熟设计组合技术；本稿不以增加参数或张量乘积作新成果。 |

具体区别：Zauner的设计由一组作用于同一Hilbert空间的投影构成，并按张量矩、degree和可分解正交类研究；本稿对象是一个分块代数中的正元素，强度取决于S_v逐点稳定子平均。把本稿全块P在H_C下取轨道，的确能得到Zauner意义的regular/coherent集合，Misawa已在Remark7.5建立这一步。因此“可纳入Zauner宽定义”是肯定的；“Zauner具体计算了本稿最优值及分类”在上述原文中未发现。

## 3. Goedicke–Vicary2023

Paulina L. A. Goedicke、Jamie Vicary，《A Categorical Model for Classical and Quantum Block Designs》，EPTCS397，118–136，2023-12-14，DOI10.4204/EPTCS.397.8，arXiv:2312.09264。

原文：https://arxiv.org/pdf/2312.09264 。出版页：https://cgi.cse.unsw.edu.au/~eptcs/paper.cgi?ACT2023.8 。本次读取19页全文文本，包括附录，重点核对§2.2和§5.2–5.3。

- 定义2.10–2.12（PDF第4页）：投影集合、统一/regular性质、degree＝不同重叠迹值数；引用Zauner定义。
- Theorem5.9（PDF第10页）：特定CP映射子类编码Zauner的统一regular degree1量子设计；不是本稿强度k的等价定义。
- Proposition5.11（PDF第12页）：从categorical经典设计到量子设计的函子；它不是本稿子群稳定子最小不可约维数的最优判据。
- 宽泛QDesign范畴可以容纳许多正/CP对象，不能仅凭这个容纳关系认定本稿具体最优值已经被证明。
- 未见本稿AGL局部±特征空间分类或PGL₂强度三族的明示结果。

数学上，不能将本稿PGL设计不经验证直接称为GV的degree1子类；其强度条件没有强制所有不同投影的重叠迹相同。

## 4. Gromada相关工作

Daniel Gromada，《Quantum association schemes》，arXiv:2404.06157v2，版本日期2026-02-09，PDF正文日期2026-02-10。链接：https://arxiv.org/pdf/2404.06157v2 。

本次读取37页全文文本，§1–2、§4相关论证重点比对；未对全部图示代数等式独立复算。

- Definition2.1（PDF第6页）：quantum coherent algebra，两种乘法与两种对合。
- Definition4.23（PDF第26页）：一般quantum association scheme。
- Theorem4.29（PDF第28页）：量子translation scheme及Fourier对偶。
- 主文处理距离regular/stronglyregular量子图、Hadamard/translation对偶、quantumLatin squares；全文没有本稿强度与最优effective-size体系的具体明示结果。
- Gromada《Some examples of quantum graphs》，arXiv:2109.13618v3（2022-09-06，论文页日期2022-09-07），本次也已获取全文PDF并直接读取引言及§1相关基础定义，核查其直和迹、图例和twisting定位；没有逐项复核后面所有图构造。链接：https://arxiv.org/pdf/2109.13618v3 。量子Cayley图/Hadamard其他相关工作为本理论基础并由Misawa/Gromada引用；本次未全部获取并读完，因此不能声称Gromada的所有论文已完成优先权排查。

审核结论：主文提供本稿使用的量子关联方案基础；没有在本次读取的主文里看到这组局部表示最优值及PGL族。额外相关文献仍需独立复核，优先权检查有这一明确范围限制。

## 5. 追加关键词检索

本次按用户要求追加以下字面主题及变体：

- quantum Johnson / optimal design / projective；
- affine 2-transitive design / affine two-transitive quantum block design；
- orbit design / quantum block / sharply transitive；
- PGL(2,q) quantum block design / strength3 / stabilizer。

检索发现大量相邻但不同对象：SIC的二重传递对称、Hoggar lines、传统PGL₂三设计、spontaneous-emission error designs、quantumLDPC或Johnson–Lindenstrauss变换。它们不能仅凭关键词重叠当成本稿的先行定理，也不能忽略其可能的数学关系。

一条搜索摘要将“An optimal quantum block design”误归为其他作者的2023–2024论文。追查标题后，它实际上是Misawa原文§8节标题；没有找到可核查的那篇独立论文，故不作为先行文献或来源。

另检索到Jun-Ling Zhou、Yan-Xun Chang的PGL/PSL spontaneous-emission设计线索，搜索给出2016论文“3-Spontaneous Emission Error Designs from PSL(2,q) or PGL(2,q)”。当前只有书目/二手概述，未直接取到该原文。本稿明确不声称首创PGL三传递的量子相关用途，也不称已排除该线索；它的经典子集轨道/量子jump-code对象与本稿块代数平均定义不同，确切比较列为未完成事项。

搜索摘要还多次把直和M_d的空间解释成若干qubit、把Misawa强度混成Haar张量矩或把所有PGL轨道误称Steiner系统；这些都未进入证明。

## 6. 归属矩阵与可发表性判断

| 结果 | 归属/级别 |
|---|---|
| 量子Johnson空间与强度平均定义 | Misawa，继承。 |
| 轨道生成、Schur平均、coherence | Zauner及标准表示理论，继承。 |
| t=k等块迹与纯度下界 | 原例的初等一般化，工具级。 |
| 局部最小不可约维数给出对称最优值和全部等号解 | 本稿具体推导，有自包含证明；未见所读原文明示，优先权待核。 |
| AGL无穷族及对称解分类 | 上一研究阶段具体延伸；原作F₅部分明确扣除。 |
| PGL₂二重传递奇/偶对称障碍 | 本稿新增具体族与判据应用；优先权待核。 |
| PGL₂强度三最优族、S₃重数公式、符号分支 | 本阶段新增主结果候选；一般证明及有限精确回归，尚无独立专家审议。 |

判断：可以继续完善成一篇结构清楚的研究稿，核心放在定理5和7及其明确障碍，不能以“量子设计重大突破”“首创群轨道法”“已有同行认可”对外描述。本文未解决Misawa Problem7.6的一般识别问题，也没有声称更强量子码。
