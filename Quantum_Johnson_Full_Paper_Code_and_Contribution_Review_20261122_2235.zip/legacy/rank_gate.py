"""Rank gate at positive q/n; exact diagnostics, not a rank formula for
three positive composition proportions. Closing status is in rank_archive.md.
"""
from itertools import combinations
from math import comb,log
from pathlib import Path
import json

def rank(vs):
 piv={}
 for v in vs:
  while v:
   k=v.bit_length()-1
   if k in piv:v^=piv[k]
   else:piv[k]=v;break
 return len(piv)

def layer(n,km,kp):
 for a in combinations(range(n),km):
  for b in combinations([x for x in range(n) if x not in a],kp):
   yield tuple(-1 if x in a else 1 if x in b else 0 for x in range(n))

def selector(L,u,q):
 return [sum(int((u-sum(a*b for a,b in zip(x,y)))%q==0)<<i for i,y in enumerate(L)) for x in L]

def contingency(x,y):
 return tuple(sum(a==i and b==j for a,b in zip(x,y)) for i in [-1,0,1] for j in [-1,0,1])

def quotient(n,km,kp,q):
 L=list(layer(n,km,kp));rows=selector(L,km+kp,q);x=L[0];classes={}
 for i,y in enumerate(L):classes.setdefault(contingency(x,y),[]).append(i)
 parts=list(classes.values());Q=[]
 for part in parts:
  i=part[0];row=sum(((rows[i] & sum(1<<j for j in cell)).bit_count()%2)<<s for s,cell in enumerate(parts));Q.append(row)
  for i2 in part:
   test=sum(((rows[i2] & sum(1<<j for j in cell)).bit_count()%2)<<s for s,cell in enumerate(parts));assert test==row
 return {'n':n,'q':q,'q_over_n':q/n,'composition':[km,n-km-kp,kp],'layer_size':len(L),'orbital_quotient_dimension':len(Q),'quotient_rank_F2':rank(Q),'full_selector_rank_F2':rank(rows),'equitable_verified':True,'sufficient_strict_window':-2*min(km,kp)>km+kp-2*q}

out=[]
for arg in [(8,1,3,4),(8,2,2,4),(12,1,2,4)]:
 r=quotient(*arg);out.append(r);print(r,flush=True)
# J2 is nonzero nilpotent over F2: real eigenvalue count modulo 2 is unsafe.
assert rank([3,3])==1
assert ((1+1)%2)==0
# W W^T can lose rank, even though inclusion W has positive rank.
W=[3];assert rank(W)==1 and (3&3).bit_count()%2==0

binary=[]
for q in [2,4,8,16,32,64,128]:
 n=2*q;V=comb(n,q);assert V%2==0
 # on q-subsets of 2q points, modular selector is identity plus complement.
 # every complementary pair supplies one rank-one 2x2 all-ones block.
 R=V//2
 if q<=4:
  S=list(combinations(range(n),q));sets=[set(a) for a in S]
  rows=[sum(int((q-len(a&b))%q==0)<<j for j,b in enumerate(sets)) for a in sets]
  assert rank(rows)==R
 binary.append({'q':q,'n':n,'ratio':0.5,'layer_size':str(V),'rank':str(R),'rank_over_layer':'1/2','log2_rank_per_coordinate':log(R,2)/n})
result={'ternary_formula_found':False,'positive_density_asymptotic_gain_proved':False,'decision':'STOP_AND_ARCHIVE','three_routes':['orbital algebra quotient','modular characteristic diagnostics','complement-pair block decomposition'],'quotient_diagnostics':out,'binary_exact_formula':'rank_F2 M(n=2q,r=q)=binom(2q,q)/2, q a power of 2','binary_results':binary,'binary_only_constant_factor_gain':True,'nilpotent_eigenvalue_and_gram_counterexamples_passed':True,'passed':True}
Path(__file__).with_name('rank_gate_results.json').write_text(json.dumps(result,indent=2))
