"""Re-run every mathematical certificate shipped in this package.
Not an external peer review or priority certificate. Do not run Python -O.
"""
from pathlib import Path
import subprocess,sys,json
ROOT=Path(__file__).resolve().parent
if not __debug__:raise RuntimeError('Assertions required')
expected={n:json.loads((ROOT/n).read_text()) for n in ['projective_results.json','classification_results.json','rank_gate_results.json']}
for script in ['projective_verify.py','classification_verify.py','rank_gate.py']:
 p=subprocess.run([sys.executable,str(ROOT/script)],cwd=ROOT,text=True,capture_output=True,timeout=180)
 print(p.stdout)
 if p.returncode:raise RuntimeError(script+'\n'+p.stderr)
for n,v in expected.items():assert json.loads((ROOT/n).read_text())==v,n
p=json.loads((ROOT/'projective_results.json').read_text())
c=json.loads((ROOT/'classification_results.json').read_text())
assert p['passed'] and c['passed']
by_q={r['q']:r for r in c['results']}
for r in p['results']:
 if r['k']==3:
  assert [r['m0'],r['ms']]==by_q[r['q']]['exact_rational_projector_ranks']
assert json.loads((ROOT/'rank_gate_results.json').read_text())['decision']=='STOP_AND_ARCHIVE'
print('Exact certificate suite passed; rank branch remains STOP_AND_ARCHIVE.')
