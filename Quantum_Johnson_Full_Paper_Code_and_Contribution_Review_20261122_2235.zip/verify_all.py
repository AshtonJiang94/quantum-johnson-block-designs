from pathlib import Path
import sys,subprocess,json
ROOT=Path(__file__).resolve().parent
if not __debug__:raise RuntimeError('Run without Python -O')
for script,out in [('projective_verify.py','projective_results.json'),('classification_verify.py','classification_results.json'),('new_methods_verify.py','new_methods_results.json')]:
 expected=json.loads((ROOT/'code'/out).read_text())
 p=subprocess.run([sys.executable,str(ROOT/'code'/script)],cwd=ROOT/'code',capture_output=True,text=True,timeout=240)
 print(script,p.returncode)
 if p.returncode:raise RuntimeError(p.stdout+p.stderr)
 assert json.loads((ROOT/'code'/out).read_text())==expected,out
print('Three exact suites passed. Archived rank branch is not resumed.')
