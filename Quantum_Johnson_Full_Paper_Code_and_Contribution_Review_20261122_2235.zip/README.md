# Revised quantum Johnson paper

Author: JIANG ZHICHENG (no affiliation, no work email — author decision 2026-11-22, consistent with the Sunflower paper).

manuscript/: complete English Word with editable OMML equations and standalone LaTeX; Chinese one-page contribution assessment in Word and PDF. If a paper PDF is present, it is converted from Word, not compiled from LaTeX.
code/: new and previous exact finite verification; all implemented instances and coefficient rings are documented in the paper.
audit/: fresh source-reading scope, attribution, old/new comparison, unsuccessful transfers and verification records.
legacy/: dated baseline and stopped rank archive; retained for provenance, not presented as a new result.

Install requirements.txt and run python verify_all.py without -O. The three suites check reference outputs as well as assertions. Subfield q=16 calculations use Z[omega], not complex floating point. The general theorems rely on written proofs, not test counts.

New families solve different lower-strength problems. At v=9,k=3 the minima 15,60,420 correspond to strengths 1,2,3; there is no same-strength improvement from 420 to 60. The old full-space strength-three minimum cannot be lowered by tuning.

Source-page retrieval in this run found Misawa v1 only. No final priority claim or independent mathematical peer review is made. No public submission was performed. A system LaTeX engine was unavailable and installation was not permitted; TeX compilation is not claimed. The PDF, if included, comes from Word. Future TeX compilation should use pdfLaTeX with amsmath,amssymb,amsthm,geometry,hyperref, then check warnings and references.

AI materially assisted mathematical derivation, verification code, literature search and writing; AI is not an author. Old files have not been overwritten.


## Note on the Zenodo submission version (2026-11-22)
The manuscript/ folder (tex, docx, compiled PDF and the Chinese one-page
contribution assessment) was removed from this archive for the Zenodo
record: the paper itself is uploaded as the separate main PDF file, and
the one-page assessment is an internal evaluation, not part of a formal
submission. This archive therefore contains only the verification code,
audit trail, legacy material and this README. The manifest was regenerated
to match the actual contents.
