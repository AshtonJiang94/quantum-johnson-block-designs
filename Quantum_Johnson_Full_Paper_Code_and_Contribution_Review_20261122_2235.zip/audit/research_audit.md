# Reassessment and cross-field method audit

## Baseline and scope

The baseline is the delivered 20261113_0208 quantum Johnson package, not the sunflower paper. Its manuscript.md and affine_proof.md give the previous general arguments; projective_verify.py, classification_verify.py and the reference outputs give finite exact checks. The new paper incorporates those families with complete proofs, and adds separate theorems rather than implying a smaller strength-three value.

The current author information was JIANG ZHICHENG, DIP.ai, jiangzhicheng@dip-ai.com at package build time; on 2026-11-22 the author changed the manuscript byline to JIANG ZHICHENG with no affiliation and no work email, consistent with the Sunflower paper. The tex, docx and compiled PDF in this revised package carry the new byline. AI is not an author. This task creates a new package; it does not modify the previous delivery, restart the archived rank project, submit to arXiv, or communicate externally.

## What was checked again

1. Misawa's live arXiv version page and full v1 HTML were downloaded in this run. The page lists v1, submitted 7 October 2026; no v2 appears on the page retrieved. Definitions 7.2, Proposition 7.4, Remark 7.5, Theorems 8.3 and 8.6 were directly compared. The precise incumbent values remain 20 (noncentral), 40 (central), and 40/3 (the conic program). They are not changed by this paper.
2. The old local commutant proof and the PGL2 character formulas were reread. The equality classification is for a fixed subgroup and labeled space, not all non-symmetric quantum designs.
3. The three old verification entry points were rerun and matched their expected results. The rank entry remains STOP_AND_ARCHIVE; it is retained under legacy/ as an archive, not a new contribution.
4. New finite checks independently test subfield-line support, genuine finite-field arithmetic, character seeds, all affine transports, and exact matrix averages. q=16,r=4 requires a third-root-of-unity character; an attempted real trivial seed would fail because the complement has only one local orbit. It was replaced by an exact Eisenstein-integer seed and the code verifies both integer coefficient matrices. Similarly v=6,k=3 uses a genuinely complex cyclic character.

## Cross-field analysis and actual mathematical changes

### A. Classical design and covering theory: implemented

Misawa Proposition 7.4 already gives weighted trace designs. For 1 <= t <= k, their incidence constraints imply every block trace is at most S/R_t, with R_t=binom(v,t)/binom(k,t). Combining this with the positive-matrix purity bound yields esize >= d R_t. Equality requires constant-trace rank-one blocks on a Steiner t-(v,k,1) support. The central bound is d^2 R_t. This is an explicit consequence of known incidence and trace tools; it is not a newly invented universal classical covering principle.

A Steiner support is necessary at equality, but arbitrary rank-one matrices on it do not automatically satisfy Misawa's averaging condition. The paper makes this distinction explicit and gives compatible constructions rather than claiming every classical Steiner system has a quantum lift.

### B. Symmetry-reduced optimization and representation theory: implemented

The previous block-transitive formula Md r_min generalizes to multiple block orbits: min esize=d min_(orbit,irrep)(orbit size times irrep dimension). Equality uses one orbit and one rank-one multiplicity-space component; tied minimizers form a disjoint union of complex projective spaces. The proof is a weighted purity calculation after a commutant decomposition. This removes t=k and block-transitivity restrictions from the symmetric optimization theorem.

Gatermann–Parrilo's symmetry reduction provides relevant structural context, but convex SDP symmetrization cannot justify unrestricted minimization of this effective-size ratio. At fixed trace the objective asks to maximize purity, and twirling can decrease purity. No unsupported claim of convexity or global solver certification is made.

### C. Finite geometry and free stabilizer actions: implemented

For q=r^e, e>=2, k=r, affine subfield lines form a classical Steiner 2-(q,r,1) system. Their block stabilizer is AGL(1,r), which acts freely outside the base subfield. The restricted permutation representation is c regular copies; after deleting the constant line, a nontrivial one-dimensional character remains. This gives a strength-two rank-one quantum lift attaining the full lower bound d q(q-1)/[r(r-1)]. The affine geometry itself and regular-representation decomposition are standard. The candidate incremental result is their exact combination with Misawa strength and the effective-size objective.

For q=9,r=3: 12 support blocks among 84, minimum 60 and central minimum 300. For q=16,r=4: 20 among 1820, minimum 220 and central minimum 2420. The r=2 specialization overlaps the old two-point affine family and is not double-counted.

### D. Cyclic characters and partitions: implemented

For k|v and v-k>=2, a regular cyclic point action transports rank-one seeds on a partition into v/k blocks. It attains strength-one minimum d v/k and central minimum d^2 v/k. This is another simple exact family, not a high-strength breakthrough. Non-divisible v cannot attain this particular trace lower bound, because equality would require a partition.

### E. Quantum purity and extremizer stability: implemented

For an exact block-transitive symmetric design with near-optimal size, its largest multiplicity-space eigenvalue locates a nearby true minimizer. Below the irreducible-dimension gap, mean squared Hilbert–Schmidt distance is at most epsilon/[r_min(1+epsilon)]. For the old r_min=1 families this extends the earlier affine-only elementary stability statement. It concerns exact design constraints, not approximate strength and not physical noise.

### F. Other tempting transfers: not implemented as results

- Haar unitary/state designs and Clifford moment criteria use a different definition; their cardinality and moment bounds do not apply directly.
- Tensor products do not preserve the same Johnson block algebra and pointwise-stabilizer condition without a separate embedding theorem.
- A smaller symmetry group could permit lower purity-constrained effective size in obstructed cases, but no full non-symmetric optimum for v=6,k=3,t=3 was found or certified here. The honest bracket remains 40 <= optimum <= 80.
- The earlier fixed-composition finite-field rank question is not resumed.
- There is no mathematical basis here for importing theta-lift chains from the RH claim; a mechanism must act on the actual design constraints before it can be useful.

## Literature search, evidence and remaining priority work

Directly reread in this run:
- Ryutaro Misawa, Quantizing Delsarte Theory, arXiv:2610.09900v1, Definition 7.2, Proposition 7.4, Remark 7.5 and Section 8.
  https://arxiv.org/abs/2610.09900
  https://arxiv.org/html/2610.09900v1

Direct version-page / abstract verification only in this run:
- Karin Gatermann and Pablo A. Parrilo, Symmetry groups, semidefinite programs, and sums of squares, arXiv:math/0211450; JPAA 192 (2004), 95–128. The abstract confirms symmetry reduction of matrix sizes and decision variables. Full proof-level comparison was not performed now.
  https://arxiv.org/abs/math/0211450
- D. Gross, K. Audenaert and J. Eisert, Evenly distributed unitaries: on the structure of unitary designs, arXiv:quant-ph/0611002; JMP 48 (2007), 052104. The abstract confirms Haar-moment design scope. It is used as contrast, not as a transferred theorem.
  https://arxiv.org/abs/quant-ph/0611002

Prior package audit, not fresh full reading in this run:
- Zauner 1999 and author translation: definition 1.1, orbit generation and Section 3, with page locators retained in legacy/literature_audit.md.
- Goedicke–Vicary 2023, arXiv:2312.09264: the earlier audit states full-text reading including categorical degree-one/coherence distinctions. A fresh HTML fetch was not successful in the time available; no new full-reading claim is made.
- Gromada, Quantum association schemes, arXiv:2404.06157: the previous audit's definitions and reading scope remain provenance only; it was not reread in full here.

Additional web searches included exact title/version, quantum Johnson + Steiner + effective size, quantum block + subfield, and invariant positive operator/commutant/purity stability themes. The search summaries were often off-topic or conflated Haar designs with Johnson designs. They were not used to establish a prior theorem or declare its absence. No directly matching external statement of the new subfield-line effective-size formula was identified in these retrieved sources; this is not a priority certificate. Especially check general orbit-design lifting results, finite-geometric quantum block designs and general purity extremizer theorems before claiming originality.

## Contribution assessment

The most useful extension is methodological: optimize orbit size as well as local rank, rather than only filling every possible block. This yields exact lower-strength global optima and exposes a classical support structure. The subfield-line family is a substantive new parameter family relative to the old manuscript, and the stability bound supplies a quantitative structural supplement. The proofs use established tools and are mostly elementary once the correct representation is chosen. Their weight is a coherent structural extension, not a resolved major open problem or improved quantum code.

The nine-point, three-block-size case is a clean comparison: minima 15, 60, 420 at strengths 1, 2, 3 respectively, and corresponding central minima 75, 300, 2100. Cross-strength ratios describe different requirements and must never be presented as same-problem improvements. At strength three, the old optimum 420 was already sharp and remains unchanged.

## Verification limitations

Finite exact regression confirms the implemented inputs and arithmetic. It is neither a substitute for the written all-parameter proofs nor independent expert review or Lean formalization. Word uses editable native OMML; its package/XML checks are separate from mathematical validation. PDF conversion from Word, if successful, is not a successful LaTeX compile. No TeX engine is installed and installing system packages was not permitted; the LaTeX source is delivered with this limitation stated. Public submission and final authorship approval remain with the human author.
