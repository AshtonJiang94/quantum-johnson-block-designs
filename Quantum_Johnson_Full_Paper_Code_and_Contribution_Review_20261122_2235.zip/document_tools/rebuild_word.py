"""Rebuild editable Word from this paper's supported LaTeX subset.
Usage: python document_tools/rebuild_word.py --out rebuilt
Theorem numbering follows source order. External locators are never internal refs.
"""
from pathlib import Path
import argparse,importlib.util,re,tempfile
from docx import Document
from docx.oxml.ns import qn
ROOT=Path(__file__).resolve().parent.parent
p=argparse.ArgumentParser();p.add_argument('--source',type=Path);p.add_argument('--out',type=Path,default=ROOT/'rebuilt');args=p.parse_args()
source=args.source or next((ROOT/'manuscript').glob('*.tex'));args.out.mkdir(parents=True,exist_ok=True)
spec=importlib.util.spec_from_file_location('mathbuilder',ROOT/'document_tools/tex_to_omml.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
b.OUT=args.out;b.SYMS.update({'chi':'χ','sigma':'σ','tau':'τ','varnothing':'∅','sqcup':'⊔','mid':'∣','Vert':'‖','cap':'∩','supset':'⊃','equiv':'≡','omega':'ω'})
b.OPERATORS.update({'bigoplus':'⊕','bigsqcup':'⨆'});b.BBOARD['C']='ℂ';b.CAL.update({'B':'ℬ','A':'𝒜','D':'𝒟'})
original=b.Parser.atom
def atom(self):
 self.space()
 if self.s[self.i:].startswith('\\overline'):
  self.i+=len('\\overline');self.commands.append('overline')
  return b.node('acc',[b.node('accPr',[b.node('chr',attrs={'val':'¯'})]),b.wrap('e',self.argument())]),None,None
 return original(self)
b.Parser.atom=atom
s=source.read_text().replace('\\\\Orbit Decomposition',' Orbit Decomposition')
if re.search(r'\\cite\[[^\]]*\\(?:eq)?ref',s):raise ValueError('External locators cannot use manuscript result labels')
bib=re.search(r'\\begin\{thebibliography\}\{[^}]+\}(.*?)\\end\{thebibliography\}',s,re.S)
chunks=re.split(r'\\bibitem\{([^}]+)\}',bib[1]);keys=chunks[1::2];vals=chunks[2::2];bm={k:i+1 for i,k in enumerate(keys)}
s=re.sub(r'\\cite(?:\[([^\]]*)\])?\{([^}]+)\}',lambda m:'['+','.join(str(bm[k]) for k in m[2].split(','))+((', '+m[1]) if m[1] else '')+']',s)
s=re.sub(r'\\label\{[^}]+\}','',s)
s=re.sub(r'\\begin\{equation\}(.*?)\\end\{equation\}',lambda m:'\\[\n'+m[1].strip()+'\n\\]',s,flags=re.S)
s=re.sub(r'\\begin\{thebibliography\}\{[^}]+\}.*?\\end\{thebibliography\}',lambda m:'\\section*{References}\n\n'+'\n\n'.join('['+str(i+1)+'] '+v.strip() for i,v in enumerate(vals)),s,flags=re.S)
s=s.replace('\\pmod3','\\text{ mod }3').replace('\\|','\\Vert ').replace('r*=1','$r_*=1$').replace('~',' ')
with tempfile.TemporaryDirectory() as td:
 tmp=Path(td)/'word.tex';tmp.write_text(s)
 result=b.build(tmp,'Quantum_Johnson_Orbit_Steiner_Stability_EN','en',False)
d=Document(result['docx']);d.paragraphs[0].alignment=1;d.paragraphs[1].alignment=1;d.paragraphs[1].text='JIANG ZHICHENG | DIP.ai | jiangzhicheng@dip-ai.com'
zoom=d.settings.element.find(qn('w:zoom'))
if zoom is not None:zoom.set(qn('w:percent'),'100')
d.core_properties.author='JIANG ZHICHENG';d.save(result['docx']);print(result['docx'])
